import type { Meta, StoryObj } from '@storybook/react'
import { DataTable, Column } from './DataTable'
type User={ id:number; name:string; email:string; age:number }
const meta: Meta<typeof DataTable<User>> = { title: 'UI/DataTable', component: DataTable<User> }
export default meta
const users:User[]=[
  {id:1,name:'Asha',email:'asha@example.com',age:22},
  {id:2,name:'Vikram',email:'vikram@example.com',age:31},
  {id:3,name:'Rehan',email:'rehan@example.com',age:28},
  {id:4,name:'Meera',email:'meera@example.com',age:25},
]
const columns:Column<User>=[
  {key:'name',title:'Name',sortable:true},
  {key:'email',title:'Email',sortable:true},
  {key:'age',title:'Age',sortable:true},
]
export const Basic:StoryObj<typeof DataTable<User>>={ args:{ data:users, columns, selectable:true } }