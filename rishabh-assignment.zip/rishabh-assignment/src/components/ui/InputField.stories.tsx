import type { Meta, StoryObj } from '@storybook/react'
import { useState } from 'react'
import { InputField } from './InputField'
const meta: Meta<typeof InputField> = { title: 'UI/InputField', component: InputField }
export default meta
type Story = StoryObj<typeof InputField>
export const Playground: Story = { render: () => { const [v,setV]=useState(''); return (<div className="w-80"><InputField label="Email" placeholder="you@example.com" value={v} onChange={(e)=>setV(e.target.value)} variant="outlined" size="md" helperText="We never share your email."/></div>) } }
export const Password: Story = { render: () => { const [v,setV]=useState('secret'); return (<div className="w-80"><InputField label="Password" value={v} onChange={(e)=>setV(e.target.value)} type="password" passwordToggle clearable variant="filled" size="lg"/></div>) } }