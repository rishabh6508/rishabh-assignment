import { useMemo, useState } from 'react'
import { clsx } from 'clsx'
export type Column<T>={ key:keyof T; title:string; sortable?:boolean; render?:(row:T)=>React.ReactNode }
export type DataTableProps<T>={ data:T[]; columns:Column<T>[]; loading?:boolean; selectable?:boolean; onRowSelect?:(rows:T[])=>void; emptyLabel?:string }
type SortState<T>={ key:keyof T; dir:'asc'|'desc' }|null
function sortData<T>(data:T[],state:SortState<T>):T[]{ if(!state)return data; const {key,dir}=state; return [...data].sort((a:any,b:any)=>{
  const av=a[key], bv=b[key]; if(av==null) return 1; if(bv==null) return -1;
  const res=String(av).localeCompare(String(bv),undefined,{numeric:true,sensitivity:'base'}); return dir==='asc'?res:-res; })}
export function DataTable<T extends object>(props:DataTableProps<T>){
  const {data,columns,loading,selectable,onRowSelect,emptyLabel='No records'}=props
  const [sort,setSort]=useState<SortState<T>>(null); const [selected,setSelected]=useState<number[]>([])
  const sorted=useMemo(()=>sortData(data,sort),[data,sort])
  const toggle=(idx:number)=>{ if(!selectable)return; setSelected(s=>{ const next=s.includes(idx)?s.filter(i=>i!==idx):[...s,idx]; onRowSelect?.(next.map(i=>sorted[i])); return next })}
  return (<div className="overflow-x-auto">
    <table className="min-w-full text-left border border-gray-200 rounded-xl overflow-hidden">
      <thead className="bg-gray-100 text-gray-700"><tr>
        {selectable&&<th className="w-10 p-3"></th>}
        {columns.map(col=>(
          <th key={String(col.key)} className={clsx('p-3 font-semibold whitespace-nowrap select-none',col.sortable&&'cursor-pointer')}
              onClick={()=>col.sortable&&setSort(s=>(!s||s.key!==col.key)?{key:col.key,dir:'asc'}:{key:col.key,dir:s.dir==='asc'?'desc':'asc'})}>
            <span className="inline-flex items-center gap-1">{col.title}{sort?.key===col.key&&<span aria-hidden>{sort.dir==='asc'?'▲':'▼'}</span>}</span>
          </th>
        ))}
      </tr></thead>
      <tbody>
        {loading?(<tr><td colSpan={columns.length+(selectable?1:0)} className="p-6 text-center">Loading…</td></tr>)
        :sorted.length===0?(<tr><td colSpan={columns.length+(selectable?1:0)} className="p-6 text-center text-gray-500">{emptyLabel}</td></tr>)
        :sorted.map((row,idx)=>(
          <tr key={idx} className={clsx('border-t border-gray-200 hover:bg-gray-50',selectable&&'cursor-pointer',selected.includes(idx)&&'bg-blue-50')} onClick={()=>toggle(idx)}>
            {selectable&&(<td className="p-3"><input aria-label={`select row ${idx+1}`} type="checkbox" checked={selected.includes(idx)} onChange={()=>toggle(idx)} onClick={(e)=>e.stopPropagation()}/></td>)}
            {columns.map(col=>(<td key={String(col.key)} className="p-3 whitespace-nowrap">{col.render?col.render(row):String((row as any)[col.key]??'')}</td>))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>)
}