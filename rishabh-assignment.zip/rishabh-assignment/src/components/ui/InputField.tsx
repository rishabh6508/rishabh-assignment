import { clsx } from 'clsx'
import { useId, useState } from 'react'
export type InputFieldProps={
  value:string; onChange:(e:React.ChangeEvent<HTMLInputElement>)=>void;
  label?:string; placeholder?:string; helperText?:string; errorMessage?:string;
  disabled?:boolean; invalid?:boolean; type?:'text'|'password'|'email';
  variant?:'filled'|'outlined'|'ghost'; size?:'sm'|'md'|'lg'; clearable?:boolean; passwordToggle?:boolean;
}
const sizeMap={sm:'h-9 text-sm px-3 rounded-lg',md:'h-10 text-base px-3.5 rounded-xl',lg:'h-12 text-lg px-4 rounded-2xl'}
const variantMap={filled:'bg-gray-50 focus:bg-white border border-gray-200 focus:border-primary-600',outlined:'bg-white border-2 border-gray-300 focus:border-primary-600',ghost:'bg-transparent border border-gray-200 focus:border-primary-600'}
export function InputField(p:InputFieldProps){
  const {value,onChange,label,placeholder,helperText,errorMessage,disabled,invalid,type='text',variant='filled',size='md',clearable,passwordToggle}=p
  const id=useId(); const [show,setShow]=useState(false); const t=passwordToggle?(show?'text':type):type
  return (<div className="w-full">
    {label&&<label htmlFor={id} className="label mb-1">{label}</label>}
    <div className="relative">
      <input id={id} value={value} onChange={onChange} placeholder={placeholder} disabled={disabled} aria-invalid={invalid||undefined}
        className={clsx('w-full outline-none transition-colors',sizeMap[size],variantMap[variant],invalid&&'border-red-500 focus:border-red-600',disabled&&'opacity-60 cursor-not-allowed')} type={t}/>
      {passwordToggle&&type==='password'&&(
        <button type="button" onClick={()=>setShow(s=>!s)} className="absolute right-2 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded-md bg-gray-100 hover:bg-gray-200" aria-label={show?'Hide password':'Show password'}>
          {show?'Hide':'Show'}
        </button>
      )}
      {clearable&&value&&(
        <button type="button" onClick={()=>onChange({target:{value:''}} as any)} className="absolute right-2 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded-md bg-gray-100 hover:bg-gray-200 mr-1" aria-label="Clear input">Clear</button>
      )}
    </div>
    {helperText&&!invalid&&<p className="helper">{helperText}</p>}
    {invalid&&errorMessage&&<p className="error">{errorMessage}</p>}
  </div>)
}