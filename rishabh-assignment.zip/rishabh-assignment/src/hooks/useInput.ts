import { useState } from 'react'
export function useInput(initial = ''){
  const [value,setValue]=useState(initial)
  const onChange=(e:React.ChangeEvent<HTMLInputElement>)=>setValue(e.target.value)
  const clear=()=>setValue('')
  return { value,onChange,clear,setValue }
}