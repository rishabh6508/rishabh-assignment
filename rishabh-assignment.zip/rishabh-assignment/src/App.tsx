import { useMemo, useState } from 'react'
import { InputField } from './components/ui/InputField'
import { DataTable, Column } from './components/ui/DataTable'
type Person = { id:number; name:string; email:string; role:'Admin'|'Editor'|'Viewer' }
const initial:Person[]=[
  {id:1,name:'Riya Malhotra',email:'riya@example.com',role:'Admin'},
  {id:2,name:'Kunal Sharma',email:'kunal@example.com',role:'Editor'},
  {id:3,name:'Ishita Rao',email:'ishita@example.com',role:'Viewer'},
  {id:4,name:'Raghav Kapoor',email:'raghav@example.com',role:'Editor'},
]
export default function App(){
  const [query,setQuery]=useState('')
  const data=useMemo(()=>initial.filter(p=>p.name.toLowerCase().includes(query.toLowerCase())),[query])
  const columns:Column<Person>=[
    {key:'name',title:'Name',sortable:true},
    {key:'email',title:'Email',sortable:true},
    {key:'role',title:'Role',sortable:true}
  ]
  return (<div className="max-w-5xl mx-auto p-6 space-y-6">
    <div className="card">
      <h1 className="text-2xl font-semibold mb-4">Rishabh Assignment Demo</h1>
      <InputField label="Search by name" placeholder="Type a name..." value={query} onChange={(e)=>setQuery(e.target.value)} variant="outlined" size="md" clearable/>
    </div>
    <div className="card">
      <DataTable<Person> data={data} columns={columns} selectable onRowSelect={(rows)=>console.log('selected',rows)} emptyLabel="No people found"/>
    </div>
  </div>)
}